import io.restassured.RestAssured;
import io.restassured.RestAssured.*;

import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.*;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsString;


public class DistanceMatrixTest {

    @BeforeTest
    public void setUp() {
        RestAssured.useRelaxedHTTPSValidation();
    }

    @Test
    void TC01_distanceMatrix_getDistance_distanceCalculatedSuccessfully() {

        RestAssured.baseURI = "https://maps.googleapis.com";
        RestAssured.basePath = "/maps/api/distancematrix/json";


        Response response = (Response) given().log().all()
                .queryParam("origins", "Seattle")
                .queryParam("destinations", "San Francisco")
                .queryParam("key", "pleaseuseyourapikey")
                .when()
                .get()
                .then().statusCode(200)
                .assertThat()
                .body("destination_addresses[0]", contains("San Francisco, CA, USA"))
                .body("rows[0].elements[0].distance.value", contains(1299816));

    }
}




